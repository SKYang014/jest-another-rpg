const Game = require('./lib/Game');

new Game().initializeGame();
